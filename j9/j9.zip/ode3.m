[t,y] = ode45(@vdp1,[0 20],[2; 0]);
% plot(t,y)
plot(t,y(:,1),'-*b',t,y(:,2),'-or')
title('Solution of van der Pol Equation (\mu = 1) with ODE45');
xlabel('Time t');
ylabel('Solution y');
legend('y_1','y_2')