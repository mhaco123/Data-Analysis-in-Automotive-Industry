syms x a b
eqn = a*x + b == 0;
j8 = solve(eqn,x)

syms x
j88= solve(cos(x) == sin(x), x)